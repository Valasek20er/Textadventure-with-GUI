Viel Spaß!

Anleitung zum Gewinnen des Spiels:

richtige Entscheidungen: 2) Person ansprechen: Walter
			 3) In Wohnzimmer gehen
			 2) Verdächtigen Platz hinter dem Sofa; untersuchen
(optional für Zeit)	 2)Person ansprechen: Hans
			 4) In Küche gehen
			 2) Schubladen untersuchen
			 1) / 2) (random) Schublade 1 / 2 öffnen
			 3) In Flur gehen; Hindernis machen
			 3) In Schlafzimmer gehen
(optional für Code)	 2) Schlafzimmer-Bild untersuchen; 1 - 10 eingeben
			 3) Schlafen; bis 6 Uhr
			 2) In Flur gehen; Hindernis machen
			 5) In Büro gehen
			 Wenn zwischen 06:30 und 09:30:
			 3) In Geheimraum gehen
			 2) Geheimraum untersuchen; 4) 9471
			 Wenn nicht warten bis 6:30 und 09:30 oder wieder In Schlafzimmer schlafen
			 3) Weg zurück zum Vorgarten gehen.