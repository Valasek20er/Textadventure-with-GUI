import time
import sys
import random
import os
import threading
import inputimeout
import queue

#Konstantendefinitionen
Spiel = bool
test_modus = False # Setze Testmodus auf True (normaler Text) oder False (langsamer Text)
 
class Methoden():
    """Klasse für allgemeine Methoden"""
    def __init__(self):
        pass
    gui_reference = None
    print_queue = queue.Queue() #Ich liebe dich queue <3
    is_printing = False

    @staticmethod
    def set_gui_reference(gui):
        """Setzt eine Referenz auf die GUI-Klasse."""
        Methoden.gui_reference = gui

    @staticmethod
    def slow_print(text, delay=25, slow=True, callback=None):
        """Prints the text based on the test mode."""
        if Methoden.gui_reference:
            if not test_modus and slow:
                # Füge den Text in die Warteschlange ein, um ihn nacheinander auszugeben
                Methoden.print_queue.put((text, delay, callback))
                if not Methoden.is_printing:
                    Methoden.process_queue()  # Startet die Verarbeitung der Warteschlange
            else:
                # Sofort-Ausgabe ohne Verzögerung
                Methoden.gui_reference.append_text(text + "\n")
                if callback:
                    callback()
        else:
            if not test_modus and slow:
                # Terminal-Ausgabe mit Verzögerung
                for char in text:
                    sys.stdout.write(char)
                    sys.stdout.flush()
                    time.sleep(delay / 1000)  # Verzögerung in Sekunden
                print()
            else:
                print(text)
            if callback:
                callback()

    @staticmethod
    def process_queue():
        """Verarbeitet die Warteschlange und gibt den Text aus."""
        if not Methoden.print_queue.empty():
            text, delay, callback = Methoden.print_queue.get()  # get() löscht und gibt ersten Befehl aus der Warteschlange zurück

            def type_text(index=0):
                if index < len(text):
                    Methoden.gui_reference.append_text(text[index])
                    Methoden.gui_reference.textbox.update_idletasks()  # GUI Update
                    Methoden.gui_reference.root.after(delay, type_text, index + 1)  # Nächsten Buchstaben planen
                else:
                    Methoden.gui_reference.append_text("\n")
                    if callback:
                        callback()
                    Methoden.process_queue()  # Verarbeite den nächsten Befehl in der Warteschlange

            type_text()  # Starte das Tippen des Textes
            Methoden.is_printing = True  # Setze das Flag, dass ein Textdruck läuft

        else:
            Methoden.is_printing = False  # Keine weiteren Texte zum Drucken
 
    @staticmethod
    def begrenzte_eingabe(prompt: str, timeout: int) -> str:
        """Funktion für eine begrenzte Eingabe."""
        try: 
            eingabe = inputimeout.inputimeout(prompt, timeout = 5)
            return eingabe
        except inputimeout.TimeoutOccurred:
            eingabe = "timeout"
            return eingabe
    
class Game_clock(Methoden):
    def __init__(self, current_hour: int = 19, current_minute: int = 0, running: bool = False):
        self.current_hour = current_hour
        self.current_minute = current_minute
        self.running = running
 
    def tick(self):
        self.current_minute += 30
        if self.current_minute >= 60:
            self.current_minute = 0
            self.current_hour += 1
            if self.current_hour > 24:
                self.current_hour = 1
    def uhrzeit(self, callback=None):
        """Gibt die aktuelle Zeit im Format HH:MM an."""
        self.slow_print(f"Es ist {self.current_hour:02d}:{self.current_minute:02d} Uhr.")
        if callback:
            callback()
 
    def start_clock(self):
        """Startet die Spieluhr im Hintergrund."""
        if not self.running:
            self.running = True
            threading.Thread(target=self._run_clock, daemon=True).start()
 
    def _run_clock(self):
        """Erhöht die Zeit automatisch jede Minute."""
        while self.running:
            time.sleep(10) # Veränderung der Schnelligkeit der Uhrzeit
            self.tick()
 
    def stop_clock(self):
        """Stoppt die Spieluhr."""
        self.running = False

class gegenstand(Methoden):
    """Klasse für Gegenstände"""
    def __init__(self, name: str,):
        self.name = name
 
class schlüssel(gegenstand):
    """Klasse für Schlüssel"""
    def __init__(self, name: str, room_unlock: int = None):
        super().__init__(name)
        self.room = room_unlock
 
class person(Methoden):
    """Klasse für Personen (für Spieler und NPCs)"""
    def __init__(self, name: str, rolle: str = None, health: int = 3, alive: bool = True, current_room: str = None):
        self.name = name
        self.health = health
        self.alive = alive
        self.rolle = rolle
        self.current_room = current_room
    @property
    def health(self):
        return self.__health
    @health.setter
    def health(self, value):
        global Spiel
        if value <= 0:
            self.__health = 0
            Spiel = False
        else:
            self.__health = value
    def vorstellen(self, callback=None):
        """Kurze Vorstellung"""
        def after_print():
            if callback:
                callback()
        self.slow_print(f"Ich bin {self.name} und meine Rolle ist {self.rolle}", callback=after_print)

 
class spieler(person):
    """Klasse für den Spieler"""
    def __init__(self, name: str = None, health: int = 3, inventar: list = [], current_room: str = "Vorgarten"):
        super().__init__(name, None, health, True, current_room)
        self.inventar = inventar
 
    def inventar_hinzufügen(self, item: gegenstand):
        """Funktion zum Hinzufügen von Items zum Inventar"""
        self.inventar.append(item)
 
    def inventar_remove(self, item: gegenstand):
        """Funktion zum Entfernen von Items aus dem Inventar"""
        self.inventar.remove(item)
 
    def alarm_auslösen(self):
        """Funktion für das Auslösen eines Alarms"""
        self.health -= 1
        self.slow_print(f"Du hast einen Alarm ausgelöst! Deine verbleibenden Alarme sind: {self.health}.")
        if self.health <= 0:
            self.slow_print("Du hast alle Alarme ausgelöst und wurdest entdeckt.")
            Game.spiel_ende(game1)
 
    def inventar_anzeigen(self, callback=None):
        """Funktion zum Anzeigen des Inventars"""
        for item in self.inventar:
            self.slow_print(f"- {item.name}")#!
        if callback:
            callback()
 
class npc(person):
    """Klasse für NPCs"""
    def __init__(self, name: str, rolle: str, begrüßungstext: str, geredet: bool = False, item: gegenstand = None,
                 health: int = 3, current_room: str = None, available_from: tuple = None, available_to: tuple = None, strafe: bool = False):
        super().__init__(name, rolle, health, current_room)
        self.begrüßungstext = begrüßungstext
        self.geredet = geredet
        self.item = item
        self.available_from = available_from # (Stunde, Minute)
        self.available_to = available_to # (Stunde, Minute)
        self.strafe = strafe
 
    def begrüßen(self, callback=None):
        """Funktion für die Begrüßung von NPCs"""
        def after_vorstellen():
            self.slow_print(self.begrüßungstext, callback=self.item_geben)

        self.vorstellen(callback=after_vorstellen)
        self.geredet = True

    def item_geben(self):
        if self.item:
            spieler1.inventar_hinzufügen(self.item)
            self.item = None
        
    def is_available(self, current_hour, current_minute):
        """Überprüft, ob der NPC basierend auf der aktuellen Stunde und Minute verfügbar ist."""
        if self.available_from is not None and self.available_to is not None:
            from_minutes = self.available_from[0] * 60 + self.available_from[1]
            to_minutes = self.available_to[0] * 60 + self.available_to[1]
            current_minutes = current_hour * 60 + current_minute
 
            if from_minutes <= to_minutes:
                return from_minutes <= current_minutes < to_minutes
            else:
                return current_minutes >= from_minutes or current_minutes < to_minutes
        return True
 
class raum(Methoden):
    """Klasse für Räume"""
    def __init__(self, name: str, eingangstext: str, id: int, item: gegenstand = None, item_spot: str = None, npc: npc = None, nachbar_raum: list = [], locked: bool = False, visited: bool = False, task: "Task" = None, hindernis: "Hindernis" = None, gibts_npc: bool = False, zeit_sleep:bool = False):
        self.name = name
        self.eingangstext = eingangstext
        self.id = id
        self.item = item
        self.item_spot = item_spot
        self.npc = npc
        self.nachbar_raum = nachbar_raum
        self.locked = locked
        self.visited = visited
        self.task = task
        self.hindernis = hindernis
        self.gibts_npc = gibts_npc
        self.zeit_sleep = zeit_sleep
 
        räume.append(self)
 
    def sleep(self, callback=None):
        """Funktion für das Schlafen im Spiel mit GUI-Unterstützung."""
        if self.zeit_sleep:
            schlafenszeit = [1]  # Startwert

            def print_schlafenszeit():
                """Aktualisiert den Text im GUI."""
                Methoden.gui_reference.append_text(f"Schlafenszeit: {schlafenszeit[0]} Stunden\n")

            def erhöhen():
                """Erhöht die Schlafenszeit."""
                schlafenszeit[0] += 1
                print_schlafenszeit()

            def verringern():
                """Verringert die Schlafenszeit (minimum 1 Stunde)"""
                if schlafenszeit[0] > 1:
                    schlafenszeit[0] -= 1
                    print_schlafenszeit()

            def schlafen():
                """Funktion zum Schlafen"""
                game_clock.current_hour += schlafenszeit[0]
                if game_clock.current_hour >= 24:
                    game_clock.current_hour -= 24
                Methoden.gui_reference.append_text(f"Du schläfst für {schlafenszeit[0]} Stunden.\n")
                Methoden.gui_reference.append_text(f"Es ist jetzt {game_clock.current_hour:02d}:{game_clock.current_minute:02d}.\n")
                if callback:
                    callback()

            # Buttons und Text im GUI erstellen
            Methoden.gui_reference.create_button(
    ["+", "-", "Schlafen"], 
    [erhöhen, verringern, schlafen]
)

        else:
            self.slow_print("Du kannst hier nicht schlafen.")
            if callback:
                callback()
 
    def item_finden(self, spieler, callback=None):
        """Funktion für das Finden von Items"""
        def after_find():
            if callback:
                callback()

        if self.item and isinstance(self.item, bool):
            if hasattr(self, "actual_item") and self.actual_item:
                self.slow_print(f"Du findest einen {self.actual_item.name}.", callback=after_find)
                spieler.inventar_hinzufügen(self.actual_item)
                self.item = False
                self.actual_item = None
            else:
                self.slow_print("Es wurde kein Item (actual_item) für diesen Raum definiert.", callback=after_find)
        else:
            self.slow_print("Es gibt hier nichts zu finden.", callback=after_find)
 
    def raum_betreten(self, spieler, callback=None):
        """Funktion für das Betreten eines Raumes"""
        if self.locked:
            has_key = False
            for item in spieler.inventar:
                if isinstance(item, schlüssel) and item.room == self.id: #Kommentar!
                    has_key = True
                    self.locked = False
                    spieler.inventar_remove(item)
                    break
            if not has_key:
                self.slow_print(f"Der Raum {self.name} ist verschlossen, du brauchst womöglich einen Schlüssel.")
                return
 
        if self.hindernis:
            self.hindernis.kameras_ausweichen()
            return
 
        if not self.visited:
            self.slow_print(f"{self.eingangstext}")
            self.visited = True
        spieler.current_room = self.name

        if Methoden.gui_reference:
            Methoden.gui_reference.update_room_image(self.name)
 
        self.prüfe_npc_strafe(spieler)
        self.raum_möglichkeiten(callback=callback)

    def vorgarten_zurück_ende(self, game1, callback=None):
        """Funktion für das Zurückgehen in den Vorgarten"""
        self.slow_print("Du gehst zurück in den Vorgarten, aber kommst nicht mehr in die Villa.")
        game1.spiel_ende()
        if callback:
            callback()
 
    def reden(self, callback=None):
        """Funktion für das Reden mit NPCs"""
        if self.npc:
            if self.npc.geredet:
                self.slow_print("Ich habe schon mit dir geredet, hau ab!")
            else:
                self.npc.begrüßen(callback=callback)
        else:
            self.slow_print("Es gibt hier niemanden zum Reden.")
        if callback:
            callback()

    def prüfe_npc_strafe(self, spieler):
        """Überprüft, ob ein NPC im Raum ist und eine Strafe auslösen soll"""
        if self.npc and self.npc.is_available(game_clock.current_hour, game_clock.current_minute):
            if self.npc.strafe:
                self.slow_print(f"{self.npc.name} hat dich entdeckt!")
                spieler.health = 0

    def raum_möglichkeiten(self, callback=None):
        """Funktion für die Möglichkeiten in einem Raum"""
        if self.locked:
            self.slow_print(f"Der Raum {self.name} ist verschlossen, du brauchst womöglich einen Schlüssel.")
            return

        optionen = []
        aktionen = []
        i = 0

        if game_clock:
            i += 1
            optionen.append(f"{i}) Uhrzeit anzeigen")
            aktionen.append(lambda: game_clock.uhrzeit(callback=self.raum_möglichkeiten)) #lambda erstellt Funktionen, die erst später ausgeführt werden können

        if self.task and not self.task.gemacht:
            i += 1
            optionen.append(f"{i}) {self.task.name} untersuchen")
            aktionen.append(lambda: self.task.rätsel(spieler1, callback=self.raum_möglichkeiten))

        if self.item:
            i += 1
            optionen.append(f"{i}) Verdächtigen Platz: {self.item_spot}; untersuchen")
            aktionen.append(lambda: self.item_finden(spieler1, callback=self.raum_möglichkeiten))

        if self.npc and self.npc.is_available(game_clock.current_hour, game_clock.current_minute):
            i += 1
            self.gibts_npc = True
            optionen.append(f"{i}) Person ansprechen: {self.npc.name}")
            aktionen.append(lambda: self.reden(callback=self.raum_möglichkeiten))
        else:
            self.gibts_npc = False

        if self.nachbar_raum:
            for nachbar in self.nachbar_raum:
                if nachbar.name == "Vorgarten":
                    i += 1
                    optionen.append(f"{i}) In den Vorgarten gehen")
                    aktionen.append(lambda: self.vorgarten_zurück_ende(game1, callback=self.raum_möglichkeiten))
                else:
                    i += 1
                    optionen.append(f"{i}) In {nachbar.name} gehen")
                    aktionen.append(lambda nachbar=nachbar: nachbar.raum_betreten(spieler1))

        if self.zeit_sleep:
            i += 1
            optionen.append(f"{i}) Schlafen")
            aktionen.append(lambda: self.sleep(callback=self.raum_möglichkeiten))

        if spieler1.inventar:
            i += 1
            optionen.append(f"{i}) Inventar anzeigen")
            aktionen.append(lambda: spieler1.inventar_anzeigen(callback=self.raum_möglichkeiten))

        if spieler1.health:
            i += 1
            optionen.append(f"{i}) Alarme anzeigen")
            aktionen.append(lambda: self.slow_print(f"{spieler1.health} Alarme übrig.", callback=self.raum_möglichkeiten))

        if optionen:
            Methoden.gui_reference.create_button(optionen, aktionen)
        else:
            self.slow_print("Es gibt hier nichts zu tun.")

class Task(Methoden):
    def __init__(self, name: str, beschreibung: str, strafe: bool = False, gemacht: bool = False, optionen: list = [], richtige_option: int = 0, zeit_limit: int = None, reward: gegenstand = None):
        self.name = name
        self.beschreibung = beschreibung
        self.gemacht = gemacht
        self.optionen = optionen
        self.zeit_limit = zeit_limit
        self.reward = reward
        self.richtige_option = richtige_option
        self.strafe = strafe

    def rätsel(self, spieler, callback=None):
        """Starte die Aufgabe im GUI"""
        def handle_choice(choice):
            if choice == self.richtige_option:
                self.slow_print("Richtige Wahl!")
                self.gemacht = True
                if self.reward:
                    spieler.inventar_hinzufügen(self.reward)
                if callback:
                    callback()
            else:
                self.slow_print("Falsche Wahl!")
                if self.strafe:
                    spieler.alarm_auslösen()
                if callback:
                    callback()
        self.slow_print(self.beschreibung)
        #macht aus der Liste der Optionen eine Liste mit der Nummerierung +1 damit bei 1 beginnt ) und dem Text
        options = [f"{idx + 1}) {option}" for idx, option in enumerate(self.optionen)] #enumerate: Zähler für die Liste, gibt ein Tupel (index, element) zurück
        commands = [lambda choice=idx: handle_choice(choice) for idx in range(len(self.optionen))] #len gibt Anzahl der Elemente in der Liste optionen zurück, choice=idx damit der Wert in lambda Funktion gespeichert wird
        Methoden.gui_reference.create_button(options, commands) #führt die oberen Lambda Funktionen aus, wenn der Button gedrückt wird

class Hindernis(Methoden):
    def __init__(self, name: str, beschreibung: str, raum_id: int, strafe: bool = False, fail_text: str = None): # raum_id = Id des Raumes, in dem das Hindernis ist
        self.name = name
        self.beschreibung = beschreibung
        self.strafe = strafe
        self.fail_text = fail_text
        self.raum_id = raum_id
 
    def check_strafe(self, spieler):
        """Funktion für das Überprüfen der Strafe"""
        if self.strafe:
            spieler.alarm_auslösen()
            self.slow_print(self.fail_text)
        else:
            self.slow_print(self.fail_text)
 
class Kamera(Hindernis):
    def __init__(self, name: str, beschreibung: str, raum_id, strafe: bool = False, fail_text: str = "Du wurdest entdeckt"):
        super().__init__(name, beschreibung, raum_id, strafe, fail_text)

    def kameras_ausweichen(self):
        """Funktion für das Ausweichen von Kameras"""
        self.slow_print(self.beschreibung)
        aktion = random.choice(["links", "rechts", "ducken", "springen"])
        self.slow_print(f"Du musst schnell {aktion}")

        def handle_choice(choice):
            """Callback für die Auswahl"""
            if choice == aktion:
                self.slow_print("Du hast die Kamera erfolgreich umgangen.")
                ziel_raum = next((raum for raum in räume if raum.id == self.raum_id), None)
                if ziel_raum:
                    if Methoden.gui_reference:
                        Methoden.gui_reference.update_room_image(ziel_raum.name)
                    ziel_raum.raum_möglichkeiten()
            else:
                self.slow_print("Du wurdest entdeckt!")
                self.check_strafe(spieler1)
                # Zurückkehren zum vorherigen Raum
                vorheriger_raum = next((raum for raum in räume if raum.name == spieler1.current_room), None) #Kommentar!
                if vorheriger_raum:
                    vorheriger_raum.raum_betreten(spieler1)

        optionen = ["links", "rechts", "ducken", "springen"]
        aktionen = [lambda choice=opt: handle_choice(choice) for opt in optionen]
        Methoden.gui_reference.create_button(optionen, aktionen)

class Game(Methoden):
    """Klasse für das Spiel"""
    def __init__(self, Start_text: str, End_text: str,):
        self.Start_text = Start_text
        self.End_text = End_text
 
    def spiel_starten(self):
        """Funktion für den Spielstart"""
        global Spiel
        self.slow_print(self.Start_text, callback=self.continue_game)
        Spiel = True
        game_clock.start_clock()

    def continue_game(self):
        """Funktion für die Fortsetzung des Spiels (nach dem Starttext)"""
        try:
            if Spiel:
                aktueller_raum = next((raum for raum in räume if raum.name == spieler1.current_room), None)
                if aktueller_raum:
                    self.slow_print(f"Du bist im Raum {aktueller_raum.name}.", callback=self.show_room_options(aktueller_raum))
                else:
                    self.slow_print("Der Raum konnte nicht gefunden werden.")
        finally:
            game_clock.stop_clock()
            if Spiel == False or spieler1.health == 0:
                self.geschnappt()

    def show_room_options(self, aktueller_raum):
        """Zeigt die Möglichkeiten im aktuellen Raum an."""
        if aktueller_raum.gibts_npc:
            aktueller_raum.prüfe_npc_strafe(spieler1)
        if any(item.name == "Diamant" for item in spieler1.inventar):
            self.slow_print("Du hast den Diamanten gefunden! Du hast das Spiel gewonnen.")
            self.spiel_ende()
            return
        aktueller_raum.raum_möglichkeiten()

    def spiel_ende(self):
        """Funktion für das Spielende"""
        if not any(item.name == "Diamant" for item in spieler1.inventar):
            def after_end():
                Methoden.gui_reference.clear_buttons()
                Methoden.gui_reference.append_text("Das Spiel ist beendet. Schließe das Fenster, um das Spiel zu verlassen.")#!
            self.slow_print(self.End_text, callback=after_end)
        elif any(item.name == "Diamant" for item in spieler1.inventar) and spieler1.health > 0:
            def after_end():
                Methoden.gui_reference.clear_buttons()
                Methoden.gui_reference.append_text("Gratuliere, du hast das Spiel gewonnen!")
            self.slow_print("Das Spiel ist vorbei. Du hast gewonnen!", callback=after_end)
        global Spiel
        Spiel = False

    def geschnappt(self):
        """Funktion für das Geschnappt werden"""
        os.system("color 4")
        self.slow_print("Das Spiel ist aus")
        time.sleep(2)
        os.system("color 7")

räume = []

game_clock = Game_clock()

spieler1 = spieler("Spielername", current_room="Vorgarten")

game1 = Game("", "")