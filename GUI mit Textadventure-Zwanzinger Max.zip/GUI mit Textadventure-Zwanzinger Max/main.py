import modules
import random
from gui import GUI
    #-----------------------------------------Objekte erstellen-----------------------------------------
räume = []
game_clock = modules.Game_clock()

spieler1 = modules.spieler()

game1  = modules.Game("Willkommen zum Textadventure!, du bist ein Dieb und dein Ziel ist es, den Diamanten zu stehlen\n"
        "Du hast insgesamt 3 Alarme zur Verfügung, wenn du alle 3 auslöst, wirst du entdeckt und das Spiel ist vorbei.\n"
        "Du hast vorher in in deinen Vorbereitungen herausgefunden, dass der Diamant in einem geheimen Raum im Büro liegt.\n"
        "Jedoch wird der von einem Security bewacht, du musst herausfinden, wie du ihn umgehen kannst.\n"
        "Du wirst gleich in den Vorgarten der Villa gebracht, um die Mission zu beginnen. Viel Erfolg!", 
        "Das Spiel ist vorbei\nDanke für das Spielen!\n"
        "Viel Spaß beim nächsten Mal!")

#Gegenstände definieren
schlüssel_Vorgarten = modules.schlüssel("Villa Schlüssel", room_unlock = 2)
schlüssel_Wohnzimmer = modules.schlüssel("Schlüssel Flur", room_unlock = 4)
schlüssel_Küche = modules.schlüssel("Schlüssel Schlafzimmer", room_unlock = 5)
item_schlafzimmer = modules.gegenstand("Paper mit Code: 9471")
item_diamant = modules.gegenstand("Diamant")

#Tasks definieren
task1 = modules.Task("Schubladen", "Es gibt 2 Schubladen, eine davon löst einen Alarm aus, wähle weise.",
        strafe = True,
        optionen = ["Schublade 1 öffnen", "Schublade 2 öffnen",],
        richtige_option = random.randint(0,1), reward = schlüssel_Küche)
task2 = modules.Task("Schlafzimmer-Bild", "Du hast einen Safe gefunden. Versuche ihn zu öffnen. "
        "Du musst die richtige Zahl zwischen 1 und 10 herausfinden. ", strafe = False,
        optionen = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10"],
        richtige_option = random.randint(0,9), reward = item_schlafzimmer)
task3 = modules.Task("Geheimraum", "Du hast den Diamanten gefunden, musst jedoch dein Safe öffnen, um ihn zu bekommen.", strafe = True,
        optionen = ["0982", "9472", "1032", "9471", "1034", "5013"], richtige_option = 3, reward = item_diamant)

#npc definieren
npc1 = modules.npc("Walter", "Wärter", "ich bewache die Villa, und passe auf, dass hier niemand ungewüschtes Eintritt.\n"
        "Also dann, hier ist ein Schlüssel, den du brauchst um in die Villa zu kommen.\nDu kannst "
        "nur einmal in die Villa, also nutze die Gelegenheit gut.",
        item = schlüssel_Vorgarten, current_room = "Vorgarten")
npc2 = modules.npc("Hans", "Gast", "Hallo, ich bin der Hans und bin hier zu Besuch, mein guter Freund Peter ist der Securtiy in der Villa, "
        "ich gehe manchmal mit ihm von 6:30 bis 9:30 spazieren.", current_room = "Wohnzimmer", available_from = (10, 00), available_to = (6, 00))
npc3 = modules.npc("Peter", "Security", "Ich bin Peter, ich beschütze den Diamanten, du solltest nicht hier sein.",
        current_room = "Geheimraum", available_from = (10, 00), available_to = (6, 00), strafe = True)
npc4 = modules.npc("Bernhard", "Gast", "Hey, ich bin Bernhard, lass mich in Ruhe, ich will hier gemütlich mein Geschäft erledigen.", current_room = "Badezimmer")

#Hindernisse definieren
kamera1 = modules.Kamera("Kamera", "Eine Überwachungskamera beobachtet den Flur, weiche ihr aus!", raum_id = 4, strafe = True)

#Räume definieren
raum1 = modules.raum("Vorgarten", "Der Vorgarten der Villa,",
        id = 1, item = False, npc = npc1, visited = True)
raum2 = modules.raum("Wohnzimmer", "Du bist also im Wohnzimmer angekommen, auch hier schaust du dich um und siehst etwas besonderes, ein kleines Sofa.",
        id = 2, item = True, item_spot = "hinter dem Sofa", locked = True, npc = npc2)
raum3 = modules.raum("Küche", "Die Küche, hier gibt es sehr viele verschiedene Schubladen, in einer davon ist sicher ein nützliches Item versteckt.",
        id = 3, task = task1)
raum4 = modules.raum("Flur", "Du bist jetzt im Flur, hier sollten die Gäste der Villa nicht sein, deswegen gibt es hier auch Kameras, wie du weißt.",
        id = 4, locked = True, hindernis = kamera1)
raum5 = modules.raum("Schlafzimmer", "Du bist im Schlafzimmer, da hängt ein Bild an der Wand, es sieht sehr teuer aus.",
        id = 5, locked = True, task = task2, zeit_sleep = True)
raum6 = modules.raum("Badezimmer", "Du bist im Badezimmer, hier gibt es nichts besonderes.", id = 6, npc = npc4)
raum7 = modules.raum("Büro", "Du bist im Büro, hier gibt es ein riesiges Bücherregal, du weißt ganz genau, dass es hier einen geheimen Raum gibt.\n"
        "Das hast du in deinen Vorbereitungen herausgefunden. Du weißt auch, dass dort immer ein Security ist, der den Raum bewacht.\n"
        "Wenn du nur wüsstest wann er nicht da ist...", id = 7)
raum8 = modules.raum("Geheimraum", "Du bist im Geheimraum, hier ist der Diamant, er wird jedoch von einem Code bewacht. Was ist der Code?",
        id = 9, locked = False, task = task3, npc = npc3)

#actual_items definieren
raum2.actual_item = schlüssel_Wohnzimmer

#Nachbarräume definieren
raum1.nachbar_raum = [raum2]
raum2.nachbar_raum = [raum1, raum3]
raum3.nachbar_raum = [raum2, raum4]
raum4.nachbar_raum = [raum3, raum5, raum6, raum7]
raum5.nachbar_raum = [raum4]
raum6.nachbar_raum = [raum4]
raum7.nachbar_raum = [raum4, raum8]
raum8.nachbar_raum = [raum7]

def main():
    gui = GUI(game1)
    gui.mainloop()
    
if __name__ == "__main__":
    main()