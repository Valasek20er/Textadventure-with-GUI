import customtkinter as ctk
import modules
from PIL import Image
from customtkinter import CTkImage
import random

class GUI(ctk.CTk):
    """
    Klasse für das GUI und Startmenü was ein Frame ist.
    """
    def __init__(self, game):
        super().__init__()
        self.game = game
        self.funny_mode = ctk.BooleanVar(value=False)

        self.title("Textadventure")
        self.geometry("250x300")

        self.mainFrame = ctk.CTkFrame(self)
        self.mainFrame.pack(fill="both", expand=True)
        
        self.label = ctk.CTkLabel(self.mainFrame, text="Enter your name", font=("Arial", 12))
        self.label.pack(pady=10)

        self.entry = ctk.CTkEntry(self.mainFrame, font=("Arial", 12))
        self.entry.pack(pady=5)

        self.funny_mode_button = ctk.CTkSwitch(
            self.mainFrame,
            text="Funny Mode",
            font=("Arial", 12),
            variable=self.funny_mode,
            offvalue=False,
            switch_width=100,
            switch_height=50,
            border_color="orange",
            border_width=5,
            fg_color="red",
            progress_color="green",
            button_color="blue",
            button_hover_color="pink"
        )
        self.funny_mode_button.pack(pady=10)


        self.button = ctk.CTkButton(self.mainFrame, text="Start Game", font=("Arial", 12), command=self.change_frame)
        self.button.pack(pady=10)

        self.bind("<Return>", self.change_frame)

    def change_frame(self, event=None): # Man braucht event weil .bind(<Return>) automatisch einen Argument übergibta
        """
        Wechselt den Frame und startet das Spiel.
        """
        self.name = self.entry.get()
        if self.name == "":
            pass
        else:
            self.mainFrame.destroy()
            self.game_gui = MainGui(self, funny_mode=self.funny_mode.get())
            self.title(f"{self.name}'s Textadventure")
            modules.Methoden.set_gui_reference(self.game_gui)
            self.game_gui.update_room_image("Vorgarten")
            self.game.spiel_starten()
            MainGui.on_resize(self.game_gui)

class MainGui(ctk.CTkFrame):
    """
    Klasse für das MainGui (Spiel GUI) ist nur ein Frame
    """
    def __init__(self, root, funny_mode=False):
        super().__init__(root)
        self.root = root
        self.funny_mode = funny_mode

        self.root.title("Textadventure")
        root.geometry("1500x450")

        self.frame = ctk.CTkFrame(self.root)
        self.frame.pack(fill="both", expand=True)

        self.content_frame = ctk.CTkFrame(self.frame)
        self.content_frame.pack(fill="both", expand=True, pady=20, padx=20)

        self.textbox = ctk.CTkTextbox(self.content_frame, wrap="word", font=("Arial", 12))
        self.textbox.grid(row=0, column=0, pady=10, padx=10, sticky="nsew")
        self.textbox.insert("1.0", f"Welcome, Your adventure begins now!\n")
        self.textbox.configure(state="disabled")

        self.content_frame.columnconfigure(0, weight=3)
        self.content_frame.rowconfigure(0, weight=1)

        self.map_label = ctk.CTkLabel(self.content_frame, text="")
        self.map_label.grid(row=0, column=1, padx=20, pady=10, sticky="n")

        self.button_frame = ctk.CTkFrame(self.frame)
        self.button_frame.pack(pady=10, padx=20, fill="x")

        self.alien_image = Image.open("./Bilder/alien.png")
        self.alien_image = self.alien_image.resize((75, 75))
        self.alien_ctk_image = CTkImage(light_image=self.alien_image, size=(75, 75))

        self.frame.bind("<Configure>", self.on_resize)

        if self.funny_mode:

            self.alien_label = ctk.CTkLabel(self.frame, image=self.alien_ctk_image, text="")
            self.alien_label.place(x=0, y=0)
            self.funny_mode_start()
            self.animate_alien()

    def on_resize(self, event=None):
        """
        Aktualisiert die Schriftgröße der Textbox bei Größenänderung des Fensters.
        """
        self.update_idletasks()
        new_width = self.textbox.winfo_width()
        new_font_size = max(12, int(new_width / 50))
        self.textbox.configure(font=("Arial", new_font_size))

    def update_room_image(self, room_name):
        """
        Aktualisiert das Bild basierend auf dem aktuellen Raum.
        """
        try:
            image_path = f"./Bilder/map - {room_name}.jpg"
            room_image = Image.open(image_path)
            room_image = room_image.resize((300, 300))
            self.map_image = CTkImage(light_image=room_image, size=(300, 300))
            self.map_label.configure(image=self.map_image)
        except FileNotFoundError:
            self.map_label.configure(text="Kein Bild verfügbar")

    def append_text(self, text):
        """
        Fügt den Text zum Textfeld im Gui hinzu.
        """
        self.textbox.configure(state="normal")
        self.textbox.insert("end", text)
        self.textbox.configure(state="disabled")   
        self.textbox.see("end")

    def clear_buttons(self):
        """
        Löscht alle Buttons im button_frame.
        """
        for widget in self.button_frame.winfo_children(): # Nimmt alle Widgets in button_frame
            if isinstance(widget, ctk.CTkButton): # Nur wenn es ein Button ist
                widget.destroy()

    def create_button(self, options, commands):#chat gpt hat geholfen :)
        """
        Erstellt Buttons basierend auf den übergebenen Optionen und Befehlen.
        """
        self.clear_buttons()
        if modules.Spiel: 
            num_columns = min(len(options), 10)  # max column anzahl
            for i, (option, command) in enumerate(zip(options, commands)): #enumerate ist ein Zähler für die Liste, zip returnt ein Iterator (Zeiger) von Tupeln
                row, col = divmod(i, num_columns) #divmod(a, b) gibt ein Tupel (a // b, a % b) zurück, also den Quotienten und den Rest der Ganzzahldivision.
                button = ctk.CTkButton(self.button_frame, text=option, font=("Arial", 12), command=command)
                button.grid(row=row, column=col, sticky="nsew", padx=5, pady=2)

            # button grid frame layout 
            for i in range(num_columns):
                self.button_frame.columnconfigure(i, weight=1) #setzt wieviel Platz die Spalte einnimmt
            for i in range((len(options) + num_columns - 1) // num_columns): #Berechnet Anzahl d. benötigten Zeilen, len() gibt die Anzahl der Elemente in der Liste zurück
                self.button_frame.rowconfigure(i, weight=1) #setzt wieviel Platz die Zeile einnimmt

    def funny_mode_start(self):
        """
        Startet den funny Mode.
        """
        def random_color():
            return f"#{random.randint(0, 0xFFFFFF):06x}"
        
        def change_to_funnymode():
            self.frame.configure(fg_color=random_color())
            self.textbox.configure(fg_color=random_color())
            self.map_label.configure(fg_color=random_color())
            self.button_frame.configure(fg_color=random_color())
            for widget in self.button_frame.winfo_children(): #winfo_children gibt eine Liste aller child-Widgets zurück
                if isinstance(widget, ctk.CTkButton):
                    widget.configure(fg_color=random_color())
            self.after(100, change_to_funnymode)
        
        change_to_funnymode()

    def animate_alien(self):
        """
        Animates the alien flying around the textbox.
        """
        x, y = 0, 0 # Variablen müssen außerhalb der Funktion definiert werden, damit sie nicht bei jedem Funktionsaufruf zurückgesetzt werden
        dx, dy = 5, 5  # wie stark es sich bewegt

        def move_alien():
            nonlocal x, y, dx, dy

            #Größe des Frames bestimmen
            frame_width = self.frame.winfo_width()
            frame_height = self.frame.winfo_height()

            #Updated die Position des Aliens
            x += dx
            y += dy

            #Wenn das Alien die Wand trifft, Richtung ändern
            if x <= 0 or x + 50 >= frame_width:
                dx = -dx
            if y <= 0 or y + 50 >= frame_height:
                dy = -dy

            # Bewegt das Alien
            self.alien_label.place(x=x, y=y)

            # Wartet 50ms und bewegt das Alien erneut
            self.after(50, move_alien)

        move_alien()